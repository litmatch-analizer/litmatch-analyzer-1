package com.litmatch.analyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Typeface

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val symbols = listOf("Câmera", "Coroa", "Princesa", "Ursinho", "Luva", "Balões", "Sorvete", "Boia")
    private val counts = linkedMapOf<String, Int>()
    private val history = mutableListOf<Pair<String, Long>>()
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        val title = TextView(this).apply {
            text = "LITMATCH ANALYZER"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Protótipo iniciado. A captura ainda precisa ser validada."
            textSize = 14f
            setPadding(0, 20, 0, 20)
        }
        val capture = Button(this).apply {
            text = "Autorizar captura da tela"
            setOnClickListener {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        }
        val subtitle = TextView(this).apply {
            text = "\nRegistrar resultado manualmente (para validar estatísticas):"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(capture)
        layout.addView(subtitle)
        symbols.forEach { symbol ->
            layout.addView(Button(this).apply {
                text = symbol
                setOnClickListener {
                    history.add(symbol to System.currentTimeMillis())
                    counts[symbol] = (counts[symbol] ?: 0) + 1
                    status.text = "Registrado: $symbol\nTotal de rodadas: ${history.size}\n" +
                        symbols.joinToString(" • ") { "$it: ${counts[it] ?: 0}" }
                }
            })
        }
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ScreenCaptureService::class.java).apply {
                putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            }
            startForegroundService(service)
            status.text = "Permissão concedida. Captura iniciada; reconhecimento dos símbolos ainda será implementado e testado."
        } else if (requestCode == captureRequest) {
            status.text = "Captura não autorizada."
        }
    }
}
