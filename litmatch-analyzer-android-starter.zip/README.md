# Litmatch Analyzer (Android prototype)

Primeiro protótipo Android para validar:
- autorização de captura de tela via MediaProjection;
- recebimento temporário de quadros em memória;
- registro manual dos oito resultados para validar o histórico e as contagens;
- geração de APK debug pelo GitHub Actions.

## Estado real do protótipo

**Ainda não reconhece automaticamente os símbolos da roleta.** A captura recebe quadros, mas o recorte da área da roleta e o classificador visual precisam ser implementados e testados com imagens reais. O registro manual existe apenas para testar o mecanismo de histórico/contagem.

O aplicativo não grava capturas na galeria. A captura só começa após autorização explícita do Android e pode ser interrompida pelo usuário.

## Gerar APK

1. Envie todos os arquivos deste projeto para a raiz do repositório `litmatch-analyzer`.
2. Abra a aba **Actions** no GitHub.
3. Aguarde o workflow **Build Android APK** terminar.
4. Abra a execução concluída e baixe o artefato `litmatch-analyzer-debug`.
5. Extraia o ZIP do artefato para obter `app-debug.apk`.

## Próximas etapas

1. Confirmar a captura em Android 15.
2. Usar screenshots fornecidos voluntariamente para localizar a área e os oito símbolos.
3. Implementar reconhecimento visual e confiança por símbolo.
4. Persistir histórico localmente e calcular frequência, intervalos e sequências.
5. Medir desempenho das quatro sugestões em dados futuros, sem prometer previsão garantida.

As estatísticas descrevem resultados passados. Elas não provam a causa de um resultado nem garantem o próximo resultado.
